export default {
    LOGIN: 'user/login',
    TEXT: '/text'
}