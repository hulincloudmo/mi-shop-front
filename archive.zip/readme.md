#uni-app项目-商城

##知识点
### 一、使用解构赋值交换数组位置
```` javascript
    [state.addressList[0],state.addressList[index]] = [state.addressList[index],state.addressList[0]]
````

