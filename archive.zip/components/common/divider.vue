<template>
	<view>
		<view class="divider">
		    
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
.divider{
    height: 18rpx;
    background-color: #F5F5F5;
    width: 100%;
}
</style>
